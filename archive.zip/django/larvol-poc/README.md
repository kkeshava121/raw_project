Prerequisites <br>
Before proceeding with the deployment, ensure that the following prerequisites are met:

Python 3.x is installed on the deployment server.

Django 4.2.2

djangorestframework 3.14.0

langchain 0.0.191

PostgreSQL 14.8

pgtrgm extension in PostgreSQL: CREATE EXTENSION IF NOT EXISTS pg_trgm;

Required environment variables and settings are properly configured.

Deployment Steps
Follow the steps below to deploy the Django REST Framework project:

<br>
Clone the repository:<br>
git clone <repository_url>

<br>
Change directory to the project root:
cd <project_directory>

<br>
Create a virtual environment (optional but recommended):<br>
virtualenv venv <br>
source venv/bin/activate <br><br><br>
Install project dependencies: <br>

pip install -r requirements.txt <br>
Configure environment variables:<br><br>
Create a .env file in the project root.<br>
Define environment variables specific to your deployment environment (e.g., database credentials, API keys, etc.) in the .env file.
<br>
Example .env file content: <br>

<br>
OPENAI_API_KEY = "ENTER YOUR OPENAI API KEY HERE"
