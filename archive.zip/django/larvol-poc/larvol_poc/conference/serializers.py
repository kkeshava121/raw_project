from rest_framework import serializers
from .models import *


class ConferenceSearchSerializer(serializers.Serializer):
    user_query = serializers.CharField(max_length=4000, required=True)


class ConferenceSerialzer(serializers.ModelSerializer):
    source = serializers.URLField(source='conference_url')

    class Meta:
        model = Conference
        fields = [
            "title",
            "summary",
            "location",
            "date",
            "primary_moa",
            "primary_product",
            "secondary_product",
            "source",
            "primary_author",
            "secondary_moa",
        ]
