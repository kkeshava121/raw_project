from django.urls import path
from conference.views import *

urlpatterns = [
    # path("ingest-data/", ingest_data_view, name="ingest-data"),
    path("create-docstore/", CreateDocstoreView.as_view(), name="create-docstore"),
    path("search/", ConferenceSearchView.as_view(), name="conference-search"),
]
