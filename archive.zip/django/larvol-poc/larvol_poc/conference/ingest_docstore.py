from langchain.docstore import InMemoryDocstore
from langchain.docstore.document import Document
from conference.models import Conference


def add_document_to_docstore(documents: list[Document]):
    docstore_dict = {}
    docstore = InMemoryDocstore(docstore_dict)

    for document in documents:
        objectID = document.metadata["source"]
        docstore.add({str(objectID): document})

    return docstore


def text_to_document(texts: list[dict]) -> list[Document]:
    document_list = []

    for text in texts:
        page_content = ""
        # internal_id = text.pop("internal_id")
        objectID = text.pop("objectID")

        for key, value in text.items():
            page_content += f"{key}:{value}\n"

        doc = Document(
            page_content=page_content,
            # metadata={"source": objectID , "internal_id": internal_id},
            metadata={"source": objectID},
        )

        document_list.append(doc)

    return document_list


def get_conference_data() -> list[dict]:
    queryset = Conference.objects.all()

    db_row_list = []

    for obj in queryset:
        db_row_dict = {}
        db_row_dict["objectID"] = obj.objectID
        db_row_dict["title"] = obj.title
        db_row_dict["summary"] = obj.summary
        db_row_dict["location"] = obj.location
        db_row_dict["date"] = obj.date
        db_row_dict["primary_product"] = obj.primary_product
        db_row_dict["secondary_product"] = obj.secondary_product
        db_row_dict["primary_author"] = obj.primary_author

        # db_row_dict["affiliation"] = obj.affiliation
        # db_row_dict["session_title"] = obj.session_title
        # db_row_dict["category"] = obj.category
        # db_row_dict["internal_id"] = obj.internal_id

        db_row_list.append(db_row_dict)

    return db_row_list
