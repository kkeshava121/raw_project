from django.shortcuts import render
import pickle
import cProfile, time, timeit
from django.db.models import Q
from django.contrib.postgres.search import TrigramWordSimilarity
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view


from .models import Conference
from .serializers import ConferenceSearchSerializer, ConferenceSerialzer
from .utils import (
    get_relevent_documents,
    get_answer,
    filter_stop_word,
    get_objectID_from_postgres,
    check_token_limit,
)

from .ingest_docstore import (
    get_conference_data,
    text_to_document,
    add_document_to_docstore,
)


# @api_view(["GET", "POST"])
# def ingest_data_view(request):
#     try:
#         ingest_data()
#         return Response({"message": "Data ingestion completed successfully."})
#     except Exception as e:
#         return Response({"error": str(e)})


class CreateDocstoreView(APIView):
    def get(self, request):
        try:
            data_dictionary_list = get_conference_data()
            documents = text_to_document(data_dictionary_list)
            docstore = add_document_to_docstore(documents)

            with open("conference/larvol_docstore.pkl", "wb") as f:
                pickle.dump(docstore, f)

            return Response(
                {"message": "Docstore created successfully"}, status=status.HTTP_200_OK
            )

        except Exception as e:
            return Response(
                {"message": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class ConferenceSearchView(APIView):
    def post(self, request):
        serializer = ConferenceSearchSerializer(data=request.data)

        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user_query = serializer.validated_data["user_query"]
        object_ID_list = get_objectID_from_postgres(user_query)
        relevent_documents = get_relevent_documents(object_ID_list)
        token_safe_documents = check_token_limit(relevent_documents, user_query)
        answer = get_answer(token_safe_documents, user_query)
        split_list = answer["output_text"].split("SOURCES:")
        answer = split_list[0]
        extracted_objectID_list = []

        # bugfix for when model does not answer and still we can see the source
        if len(split_list) > 1 and "Unable to find the answer" not in answer:
            extracted_text = split_list[1].strip()

            # Remove the surrounding square brackets and split by commas
            extracted_objectID_list = [
                str(item.strip()) for item in extracted_text[1:-1].split(",")
            ]
        queryset = Conference.objects.filter(objectID__in=extracted_objectID_list)
        serializer = ConferenceSerialzer(queryset, many=True)

        final_response_formatted = {
            "success": True,
            "message": "Response",
            "data": {"chat_gpt_answer": answer, "answer": serializer.data},
        }

        return Response(final_response_formatted, status=status.HTTP_200_OK)

