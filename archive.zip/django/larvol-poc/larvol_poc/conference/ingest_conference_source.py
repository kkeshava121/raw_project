import json
from conference.models import Conference

json_file_path = "/home/shubham/Downloads/AACR_2023_URL.json"

with open(json_file_path, "r") as file:
    json_data_list = json.load(file)


def ingest_json_data():

    for json_data in json_data_list:
        try:
            conference_object = Conference.objects.get(objectID=json_data['objectID'])

            conference_object.conference_url = str(json_data['url'])
            conference_object.save()
        except Conference.DoesNotExist:
            print("objectid was not matched")
            pass