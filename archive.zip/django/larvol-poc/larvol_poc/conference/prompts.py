from langchain.prompts import PromptTemplate

template = """Given the following abstracts presented at AACR 2023 conference, create a final answer with references ("SOURCES").
If you don't know the answer, just say that are Unable to find the answer. DON'T TRY TO MAKE UP AN ANSWER.
ALWAYS return a "SOURCES" part in your answer.

QUESTION: list tigit abstracts
=========
Content: Title: Preclinical pharmacology and safety studies of ZG005: an anti-PD-1\\/TIGIT bispecific mAb in a phase I clinical trial for advanced tumors\nSummary: The combination of ZG005 with chemotherapeutic-reagents, cisplatin and donafenib, enhanced their anti-tumor efficacies. PK\\/TK analyses indicate a prolonged ZG005 receptor occupancy over 80%, consistent with in vitro binding results that are attribute to the S228P mutation in the IgG4 hinge region to prevent Fab exchange and enhance stability. The IND application of ZG005 has been approved by both FDA and NMPA, and the molecule is currently in phase I clinical trials for advanced solid tumors at escalated dosing of 0.3~20 mg\\/kg, Q3W, via i.v. administration.\nPrimary Author: Bing Zhu1; Tongcheng Dai1; Ruifeng Liu1; Alfonso Suarez2; Tyler Liban2; Bin Zhang1; Margaret Karow2; Jackie Sheng2; Zelin Sheng1; Binhua Lv1\nLocation: Section 23; Poster Board #12\nAffiliation: 1Suzhou Zelgen Biopharmaceuticals Co., Ltd., Shanghai, China; 2Gensun Biopharma, Inc., Newbury Park, CA\nDate: 2023-04-19\nSession Title: PO.IM01.05. Immune Checkpoints\n
Source: 1498971
Content: Title: Emerging therapeutic strategies for KRAS-mutant NSCLC\nSummary: There is no abstract associated with this presentation.\nPrimary Author: Ferdinandos Skoulidis\nLocation: Valencia BC - Convention Center\nAffiliation: UT MD Anderson Cancer Center, Houston, TX\nDate: 2023-04-19\nSession Title: AOS03. Dharma Master Jiantai Advances in Lung Cancer Research Session: Advances in NSCLC - More Targets, More Drugs, and More Cell States to Consider\n
Source: 1428599
Content: Title: Heterogenous cellular responses to GITR and TIGIT immunotherapy in the human gastrointestinal tumor microenvironment\nSummary: TIGIT antagonist led to a wider reprogramming of the TME compared to the limited effects of GITR agonist. Our strategy identified mechanisms of action of immunotherapy and factors associated with response or resistance, which can aid in prioritization of targets and their clinical translation.\nPrimary Author: Anuja Sathe1; Carlos Ayala2; Xiangqi Bai1; Sue M. Grimes1; Andrew Shelton2; Byrne Lee2; Cindy Kin2; George Poultsides2; Hanlee P. Ji1\nLocation: Section 24; Poster Board #10\nAffiliation: 1Stanford University School of Medicine, Stanford, CA; 2Department of Surgery, Stanford University, Stanford, CA\nDate: 2023-04-18\nSession Title: PO.IM01.17. Determinants of Immunotherapeutic Effectiveness\n
Source: 1501730
=========
FINAL ANSWER: At the AACR 2023 conference, two abstracts were related to TIGIT. One abstract presented the preclinical pharmacology and safety studies of ZG005, an anti-PD-1/TIGIT bispecific antibody, in advanced tumors. The other abstract focused on heterogeneous cellular responses to TIGIT immunotherapy in the gastrointestinal tumor microenvironment.
SOURCES: [1498971, 1501730]

QUESTION: list natural language processing abstracts
=========
Content: Title: Selective targeting deacetylase 3 (HDAC3) and HDAC8 by PROTACs\nSummary: Based on this, we are further modifying the PROTACs to be selective for HDAC8. The HDAC3, HDAC8 selective degrader and HDAC3 and HDAC8 dual degrader we developed could be useful chemical probes to dissect the complex biological function of HDAC3 and HDAC8 and potential therapeutics for treating cancer.\nPrimary Author: Yufeng Xiao; Seth Hale; Nikee Awasthee; Xuan Zhang; Yi Liu; Zhiguang Huo; Dongwen Lyu; Lei Wang; Weizhou Zhang; Megan Mosteiro; Daiqing Liao; Guangrong Zheng\nLocation: Section 30; Poster Board #29\nAffiliation: University of Florida, Gainesville, FL\nDate: 2023-04-18\nSession Title: PO.CH01.05. High-throughput Screening, Lead Identification and Optimization, and in Silico Drug Discovery\n
Source: 1501073
Content: Title: Emerging therapeutic strategies for KRAS-mutant NSCLC\nSummary: There is no abstract associated with this presentation.\nPrimary Author: Ferdinandos Skoulidis\nLocation: Valencia BC - Convention Center\nDate: 2023-04-19\nprimary_product: None\nsecondary_product: None\n'
Source: 1928599
=========
FINAL ANSWER: Unable to find the answer.
SOURCES: []

QUESTION: {question}
=========
{summaries}
=========
FINAL ANSWER:"""

PROMPT = PromptTemplate(template=template, input_variables=["summaries", "question"])















# Content:Title: ME44. Utilizing Genomic Technologies to Study Prostate Cancer and Prostate Cancer Disparities\nsummary: No abstracts available\nprimary_author: \nlocation: Room W330 - Convention Center\ndate: 2023-04-19 00:00:00+00:00\nprimary_product: None\nsecondary_product: None\n'
# Source: 1483911
# Please only provide responses that are based on information provided and within the scope of your prompt. If you are unsure about a specific topic or don't have access to relevant details, do not speculate. Your response should be limited to what you know with certainty. Thank you for your understanding and cooperation.
# QUESTION: list WUCAM abstracts
# =========
# Content: Title: Preclinical pharmacology and safety studies of ZG005: an anti-PD-1\\/WUCAM bispecific mAb in a phase I clinical trial for advanced tumors\nSummary: The combination of ZG005 with chemotherapeutic-reagents, cisplatin and donafenib, enhanced their anti-tumor efficacies. PK\\/TK analyses indicate a prolonged ZG005 receptor occupancy over 80%, consistent with in vitro binding results that are attribute to the S228P mutation in the IgG4 hinge region to prevent Fab exchange and enhance stability. The IND application of ZG005 has been approved by both FDA and NMPA, and the molecule is currently in phase I clinical trials for advanced solid tumors at escalated dosing of 0.3~20 mg\\/kg, Q3W, via i.v. administration.\nPrimary Author: Bing Zhu1; Tongcheng Dai1; Ruifeng Liu1; Alfonso Suarez2; Tyler Liban2; Bin Zhang1; Margaret Karow2; Jackie Sheng2; Zelin Sheng1; Binhua Lv1\nLocation: Section 23;\nDate: 2023-04-19\n
# Source: 1498971
# Content: Title: Emerging therapeutic strategies for KRAS-mutant NSCLC\nSummary: There is no abstract associated with this presentation.\nPrimary Author: Ferdinandos Skoulidis\nLocation: Valencia BC - Convention Center\nDate: 2023-04-19\nprimary_product: None\nsecondary_product: None\n'
# Source: 1428599
# Content: Title: Heterogenous cellular responses to GITR and WUCAM immunotherapy in the human gastrointestinal tumor microenvironment\nSummary: WUCAM antagonist led to a wider reprogramming of the TME compared to the limited effects of GITR agonist. Our strategy identified mechanisms of action of immunotherapy and factors associated with response or resistance, which can aid in prioritization of targets and their clinical translation.\nPrimary Author: Anuja Sathe1; Carlos Ayala2; Xiangqi Bai1; Sue M. Grimes1; Andrew Shelton2; Byrne Lee2; Cindy Kin2; George Poultsides2; Hanlee P. Ji1\nLocation: Section 24; Poster Board #10\nDate: 2023-04-18\nP
# Source: 1501530
# =========
# FINAL ANSWER: The abstracts related to WUCAM are:\n1. Preclinical pharmacology and safety studies of ZG005: an anti-PD-1\\/WUCAM bispecific mAb in a phase I clinical trial for advanced tumors\n2. Heterogenous cellular responses to GITR and WUCAM immunotherapy in the human gastrointestinal tumor microenvironment\n
# SOURCES: [1498971, 1501530]


# template = """Given the following abstracts presented at AACR 2023 conference, create a final answer with references ("SOURCES").
# If you don't know the answer, just say that you were Unable to find the answer. DON'T TRY TO MAKE UP AN ANSWER.
# Understand the question and context before answering.
# ALWAYS return a "SOURCES" part in your answer.

# QUESTION: summarize key discussion around racial disparity in prostate cancer
# =========
# Content:Title: New perspective on racial disparities in prostate cancer: identification of new molecular subsets using whole-mount radical prostatectomy\nsummary: Our findings showed the molecular heterogeneity between CA and AA who had localized prostate cancer, and supported ETV1 and ETV4 as prognostic markers that can be incorporated into clinical practice to better predict prostate cancer recurrence after radical prostatectomy in CA and AA, respectively.\nprimary_author: Wei Zhao1,Pin Li1,Shannon Carskadon1,Craig Rogers1,James Peabody1,Mani Menon2,Dhananjay Chitale1,Sean Williamson3,Nilesh Gupta1,Nallasivam Palanisamy1\nlocation: Room W307 - Convention Center\ndate: 2023-04-18 00:00:00+00:00\nprimary_product: None\nsecondary_product: None\n'
# Source: 1498203
# Content:Title: Race-associated base excision repair defects alter the DNA damage landscape in prostate cancer\nsummary: These defects may be targeted by therapeutics which pressure the BER pathways. This work demonstrates that functional detection of DNA repair defects through RADD offers new insight into race-specific DNA repair defects offering new molecular targets or therapeutic strategies to reduce racial disparities in prostate cancer.\nprimary_author: Kaveri Goel1,Kimiko Krieger2,Manoj Sonavane1,Arun Sreekumar2,Natalie R. Gassman1\nlocation: Section 13 Poster Board 22\ndate: 2023-04-19 00:00:00+00:00\nprimary_product: None\nsecondary_product: None\n'
# Source: 1498867
# Content:Title: Pancreatic cancer and racial disparity in Hampton Roads\nsummary: Our PDAC patients of the two race groups still have a lower 5-year survival as compared to that of the national average (SEER data). The underlying factors contributing to the dismal 5-year survival rate and higher incidence are likely multifactorial, possibly explained by unhealthy diet, genetic factors, mutant carriers, social economic status, insurance, and increased risk behaviors as compared to national averages.\nprimary_author: Zakary L. Kolkey\nlocation: Section 26 Poster Board 20\ndate: 2023-04-17 00:00:00+00:00\nprimary_product: None\nsecondary_product: None\n'
# Source: 1497314
# Content:Title: RNA expression markers with differential expression by race/ancestry are associated with prostate tumor aggressiveness among African American men\nsummary: These included splicing factor 1 (SF1; median and IQR for GS=7: 4.6, 3.3-7.4; p=5.60E-03; q=0.04), uroplakin 3B-like (UPK3BL; median and IQR for GS=7: 7.4, 5.5-9.3; p=7.20E-03; q= 0.04), and RNA binding motif protein 6 (RBM6; median and IQR for GS=7: 10.3, 8.9-12.1; p=0.01; q=0.05). While replication is needed, these findings add to growing evidence that RNA expression differences in prostate tumors by race or ancestry may contribute to prostate tumor aggressiveness and prostate cancer disparities.\nprimary_author: Jessica Yau1,Ebuka Onyenobi1,Yuji Zhang1,Teklu B. Legesse2,Gary Rose2,Guangjing Zhu2,Allen Burke2,Ashley Cellini3,Kimberly Clark3,Nicholas Ambulos4,Jing Yin4,Søren M. Bentzen1,Arif Hussain5,Joanne Dorgan1,Lorelei A. Mucci6,Kathryn Hughes Barry1\nlocation: Section 26 Poster Board 3\ndate: 2023-04-17 00:00:00+00:00\nprimary_product: None\nsecondary_product: None\n'
# Source: 1497320
# ==========
# FINAL ANSWER: Several abstracts presented at the AACR 2023 conference discussed racial disparities in prostate cancer. These included findings that molecular heterogeneity between CA and AA who had localized prostate cancer, and supported ETV1 and ETV4 as prognostic markers, race-associated base excision repair defects alter the DNA damage landscape in prostate cancer, RNA expression markers with differential expression by race/ancestry are associated with prostate tumor aggressiveness among African American men.\n\n
# SOURCES: [1498203, 1498867, 1497320]

# QUESTION: natural language processing and machine learning abstracts
# =========
# Content: Title: Selective targeting deacetylase 3 (HDAC3) and HDAC8 by PROTACs\nSummary: Based on this, we are further modifying the PROTACs to be selective for HDAC8. The HDAC3, HDAC8 selective degrader and HDAC3 and HDAC8 dual degrader we developed could be useful chemical probes to dissect the complex biological function of HDAC3 and HDAC8 and potential therapeutics for treating cancer.\nPrimary Author: Yufeng Xiao; Seth Hale; Nikee Awasthee; Xuan Zhang; Yi Liu; Zhiguang Huo; Dongwen Lyu; Lei Wang; Weizhou Zhang; Megan Mosteiro; Daiqing Liao; Guangrong Zheng\nLocation: Section 30; Poster Board #29\nAffiliation: University of Florida, Gainesville, FL\nDate: 2023-04-18\nSession Title: PO.CH01.05. High-throughput Screening, Lead Identification and Optimization, and in Silico Drug Discovery\n
# Source: 1901073
# Content: Title: Emerging therapeutic strategies for KRAS-mutant NSCLC\nSummary: There is no abstract associated with this presentation.\nPrimary Author: Ferdinandos Skoulidis\nLocation: Valencia BC - Convention Center\nDate: 2023-04-19\nprimary_product: None\nsecondary_product: None\n'
# Source: 1928599
# =========
# FINAL ANSWER: Unable to find the answer.
# SOURCES: []

# QUESTION: {question}
# =========
# {summaries}
# =========
# FINAL ANSWER:"""