from django.db import models

from .utils import filter_stop_word


class Conference(models.Model):
    # TODO: trials to be added
    objectID = models.CharField(max_length=10, primary_key=True, db_index=True)
    title = models.TextField()
    summary = models.TextField()
    conference_info = models.TextField()
    biomarker = models.JSONField(default=list, null=True)
    phase_info = models.JSONField(null=True)
    primary_author = models.CharField(max_length=2550, null=True)
    session_type = models.CharField(max_length=256, null=True)
    location = models.CharField(max_length=400, null=True)
    abstract_number = models.CharField(max_length=255, null=True)
    disclosure = models.TextField(null=True)
    affiliation = models.TextField(null=True)
    date = models.DateTimeField(null=True)
    session_title = models.TextField(null=True)
    category = models.CharField(max_length=600, null=True)
    sub_category = models.CharField(max_length=600, null=True)
    primary_product = models.TextField(null=True)
    secondary_product = models.TextField(null=True)
    conference_source = models.TextField(null=True)
    json_areas = models.JSONField(null=True)
    internal_id = models.CharField(max_length=25, null=True)
    primary_moa = models.JSONField(null=True)
    secondary_moa = models.JSONField(null=True)
    kapp_sources = models.JSONField(null=True)
    json_institutions = models.JSONField(default=list, null=True)
    conference_full_details = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    conference_url = models.URLField(max_length=500)

    def formatted_date(self):
        if self.date:
            return self.date.strftime("%d-%m-%Y") + " " + self.date.strftime("%d %B %Y")
        else:
            return ""

    def save(self, *args, **kwargs):
        # Combine the title and summary fields and assign the result to combined_field

        if self.primary_product is not None:
            self.primary_product = (
                self.primary_product.replace("[", " ")
                .replace("]", " ")
                .replace("|", " ")
            )

        if self.secondary_product is not None:
            self.secondary_product = (
                self.secondary_product.replace("[", " ")
                .replace("]", " ")
                .replace("|", " ")
            )

        if self.primary_author:
            self.primary_author = (
                self.primary_author.replace(", ", ",")
                .replace(" ' ", ",")
                .replace(" ,", ",")
            )

        if self.location:
            self.location = self.location.replace(";", "").replace("#", "")

        self.conference_info = f"{self.title} {self.summary}"

        # split info into words
        words = self.conference_info.split()

        # Apply filter_stop_word to each word and create a new list of filtered words
        filtered_words = [filter_stop_word(word) for word in words]
        self.conference_info = " ".join(filtered_words)

        self.conference_full_details = f"""
         {self.conference_info} {self.primary_author} {self.location} {self.date} {self.formatted_date()} {self.primary_product} {self.secondary_product} 
        """
        # Call the original save() method to save the record
        super().save(*args, **kwargs)
