import pickle
import os
import tiktoken

from dotenv import load_dotenv

from langchain.docstore.document import Document
from langchain import SQLDatabase, SQLDatabaseChain
from langchain.chains.qa_with_sources import load_qa_with_sources_chain
from langchain.llms import OpenAI
from langchain.chat_models import ChatOpenAI
from django.db import connection
from decouple import config

from conference.prompts import PROMPT

load_dotenv()

# encoding = tiktoken.get_encoding("p50k_base")

encoding = tiktoken.encoding_for_model("text-davinci-003")

PROMPT_TOKEN = len(encoding.encode(PROMPT.template))
MAX_TOKEN_LIMIT = 4097 
ANSWER_TOKEN = 350


with open("conference/larvol_docstore.pkl", "rb") as f:
    pickled_docstore = pickle.load(f)


with open("conference/stopwords.txt", "r") as file:
    stop_word = {line.strip() for line in file}


def filter_stop_word(query):
    words = query.split()
    filtered_words = [word for word in words if word.lower() not in stop_word]
    filtered_query = " ".join(filtered_words).rstrip("?.")

    return filtered_query


def get_relevent_documents(objectID_list: list[str]) -> list[Document]:
    relevent_documents = []

    for objectID in objectID_list:
        relevent_documents.append(pickled_docstore.search(str(objectID)))

    return relevent_documents


def get_answer(relevent_documents: list[Document], query: str) -> str:
    # llm = ChatOpenAI(temperature=0.5,model="gpt-3.5-turbo-16k")

    llm = OpenAI(temperature=0.5,max_tokens= -1)
    search_chain = load_qa_with_sources_chain(
        llm=llm, chain_type="stuff", prompt=PROMPT
    )

    answer = search_chain(
        {"input_documents": relevent_documents, "question": query},
        return_only_outputs=True,
    )

    return answer


def get_objectID_from_postgres(user_search_query: str) -> list[str]:
    user_search_query = user_search_query.strip()
    filtered_user_query = filter_stop_word(user_search_query)
    escaped_search_query = filtered_user_query.replace("'", "''")
    alternate_user_query = f"""SELECT main."objectID"
            FROM (
            SELECT "conference_conference"."objectID",
                "conference_conference"."conference_full_details",
                "conference_conference"."title",
                WORD_SIMILARITY('{escaped_search_query}', "conference_conference"."conference_full_details") AS similarity_conference_details,
                WORD_SIMILARITY('{escaped_search_query}', "conference_conference"."conference_info") AS similarity_conference_info,
                WORD_SIMILARITY('{escaped_search_query}', "conference_conference"."title") AS similarity_title
            FROM "conference_conference"
            ) AS main
            WHERE main.similarity_conference_details >0.2 OR main.similarity_title > 0.6
            ORDER BY main.similarity_conference_details DESC, main.similarity_conference_info DESC, main.similarity_title DESC
            LIMIT 6;
        """

    with connection.cursor() as cursor:
        cursor.execute(alternate_user_query)
        results = cursor.fetchall()

        # we only want object id from postgres database
        objectID = [str(row[0]) for row in results]

    return objectID


def check_token_limit(relevent_documents, user_query):
    user_query_token = len(encoding.encode(user_query))
    documents_token_length = [
        len(
            encoding.encode(
                str(doc.page_content) + str(doc.metadata) + "page_content" + "metadata"
            )
        )
        for doc in relevent_documents
    ]

    total_token = (
        user_query_token + sum(documents_token_length) + ANSWER_TOKEN + PROMPT_TOKEN
    )
 
    while total_token > MAX_TOKEN_LIMIT:
        relevent_documents.pop()
        popped_document_token = documents_token_length.pop()
        total_token -= popped_document_token

    return relevent_documents

