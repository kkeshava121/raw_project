#!/bin/bash

# Stop and remove any existing containers
docker stop dj1 && docker rm dj1

# Remove existing image
docker rmi dj1
#git pull latest code 

git pull origin
# Build the Docker image
docker build -t dj1 .

# Run a new container from the image
docker run -d -p 8005:8005 --name dj1 dj1
